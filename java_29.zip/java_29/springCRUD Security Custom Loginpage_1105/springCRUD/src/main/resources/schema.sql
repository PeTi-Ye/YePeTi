DROP TABLE IF EXISTS STUDENT;

CREATE TABLE STUDENT (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  sname VARCHAR(250) NOT NULL,
  scity VARCHAR(250) NOT NULL,
  hike_length VARCHAR(250) NOT NULL

);




DROP TABLE IF EXISTS HIKE;

CREATE TABLE HIKE (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  start_point VARCHAR(250) NOT NULL,
  end_point VARCHAR(250) NOT NULL,
  hike_length VARCHAR(250) NOT NULL,
  hike_maxheight VARCHAR(250) NOT NULL,
  hike_minheight VARCHAR(250) NOT NULL,
  hike_period VARCHAR(250) NOT NULL,
  recommended_season VARCHAR(250) NOT NULL,
  route_description VARCHAR(250) NOT NULL,
  tour_level VARCHAR(250) NOT NULL,
  open_or_close VARCHAR(250) NOT NULL

);

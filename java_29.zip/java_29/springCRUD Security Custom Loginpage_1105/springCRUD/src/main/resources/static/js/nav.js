




ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}






//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


/*
* {
  box-sizing: border-box;

}*/

.column {
  width: 33.33%;
  padding: 10px;

   display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;

}

.doboz1{
  box-shadow: rgb(38, 57, 77) 0px 20px 30px -10px;
   border-style: solid;
  border-width: medium;
  width: 500px;
  height: 300px;

}

/* Clearfix (clear floats) */
.row::after {
  padding: 10px;
  content: "";
  clear: both;
  display: table;

   display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;

}

   input, button {
        box-shadow: rgb(38, 57, 77) 0px 20px 30px -10px;
    }


package com.nilesh.springCRUD.services.repository;

import com.nilesh.springCRUD.model.UsersRoles;
import com.nilesh.springCRUD.model.WaterHike;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface UsersRolesRepository extends JpaRepository<UsersRoles, Long> {

}
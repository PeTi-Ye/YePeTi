package com.nilesh.springCRUD.model;


import javax.persistence.*;


@Entity
@Table(name = "users_roles")
public class UsersRoles {


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Id
    @Column(name = "user_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    public Long getRole_id() {
        return role_id;
    }

    public void setRole_id(Long role_id) {
        this.role_id = role_id;
    }

    private Long role_id;


}




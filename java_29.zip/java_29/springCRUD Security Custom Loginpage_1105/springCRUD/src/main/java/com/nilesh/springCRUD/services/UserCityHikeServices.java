package com.nilesh.springCRUD.services;

import com.nilesh.springCRUD.model.UserCityHike;
import com.nilesh.springCRUD.services.repository.UserCityHikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserCityHikeServices {


    @Autowired
    private UserCityHikeRepository repo;


    public List<UserCityHike> listAll(){

        return repo.findAll();
    }

    public void save(UserCityHike stu) {
        repo.save(stu);
    }
    public UserCityHike get(long id) {
         return repo.findById(id).get();
    }

    public void delete(long id) {
        repo.deleteById(id);
    }





}

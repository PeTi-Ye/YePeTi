package com.nilesh.springCRUD.services;

import com.nilesh.springCRUD.model.UsersRoles;
import com.nilesh.springCRUD.model.WaterHike;
import com.nilesh.springCRUD.services.repository.UsersRolesRepository;
import com.nilesh.springCRUD.services.repository.WaterHikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersRolesServices {


    @Autowired
    private UsersRolesRepository repo;


    public List<UsersRoles> listAll(){
        return repo.findAll();
    }

    public void save(UsersRoles stu) {
        repo.save(stu);
    }
    public UsersRoles get(long id) {
        return repo.findById(id).get();
    }

    public void delete(long id) {
        repo.deleteById(id);
    }


}

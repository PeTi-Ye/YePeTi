package com.nilesh.springCRUD.model;

public enum StatusEnum {
    OPEN,
    CLOSE
}

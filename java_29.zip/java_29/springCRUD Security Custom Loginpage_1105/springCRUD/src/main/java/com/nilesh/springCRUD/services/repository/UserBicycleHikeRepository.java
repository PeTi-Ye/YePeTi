package com.nilesh.springCRUD.services.repository;

import com.nilesh.springCRUD.model.UserBicycleHike;
import com.nilesh.springCRUD.model.UserWaterHike;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface UserBicycleHikeRepository extends JpaRepository<UserBicycleHike, Long> {

}
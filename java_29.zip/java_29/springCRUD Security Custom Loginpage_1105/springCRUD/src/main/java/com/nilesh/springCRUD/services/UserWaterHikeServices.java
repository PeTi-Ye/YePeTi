package com.nilesh.springCRUD.services;

import com.nilesh.springCRUD.model.UserCityHike;
import com.nilesh.springCRUD.model.UserWaterHike;
import com.nilesh.springCRUD.services.repository.UserCityHikeRepository;
import com.nilesh.springCRUD.services.repository.UserWaterHikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserWaterHikeServices {


    @Autowired
    private UserWaterHikeRepository repo;


    public List<UserWaterHike> listAll(){

        return repo.findAll();
    }

    public void save(UserWaterHike stu) {
        repo.save(stu);
    }
    public UserWaterHike get(long id) {
         return repo.findById(id).get();
    }
    public void delete(long id) {
        repo.deleteById(id);
    }




}

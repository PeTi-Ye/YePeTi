package com.nilesh.springCRUD.services;

import com.nilesh.springCRUD.model.WaterHike;
import com.nilesh.springCRUD.services.repository.WaterHikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WaterHikeServices {


    @Autowired
    private WaterHikeRepository repo;


    public List<WaterHike> listAll(){
        return repo.findAll();
    }

    public void save(WaterHike stu) {
        repo.save(stu);
    }
    public WaterHike get(long id) {
        return repo.findById(id).get();
    }

    public void delete(long id) {
        repo.deleteById(id);
    }


}

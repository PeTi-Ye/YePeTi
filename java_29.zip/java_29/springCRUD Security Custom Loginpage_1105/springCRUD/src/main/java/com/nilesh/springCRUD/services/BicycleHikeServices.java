package com.nilesh.springCRUD.services;

import com.nilesh.springCRUD.model.*;
import com.nilesh.springCRUD.services.repository.BicycleHikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BicycleHikeServices {


    @Autowired
    private BicycleHikeRepository repo;


    public List<BicycleHike> listAll(){
        return repo.findAll();
    }

    public void save(BicycleHike stu) {
        repo.save(stu);
    }
    public BicycleHike get(long id) {
        return repo.findById(id).get();
    }

    public void delete(long id) {
        repo.deleteById(id);
    }




}

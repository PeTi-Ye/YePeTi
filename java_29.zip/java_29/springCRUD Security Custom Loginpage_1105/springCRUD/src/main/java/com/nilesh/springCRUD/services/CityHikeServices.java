package com.nilesh.springCRUD.services;

import com.nilesh.springCRUD.model.CityHike;
import com.nilesh.springCRUD.services.repository.CityHikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CityHikeServices {


    @Autowired
    private CityHikeRepository repo;


    public List<CityHike> listAll(){

        return repo.findAll();
    }

    public void save(CityHike stu) {
        repo.save(stu);
    }
    public CityHike get(long id) {
         return repo.findById(id).get();
    }

    public void delete(long id) {
        repo.deleteById(id);
    }





}

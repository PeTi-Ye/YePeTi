package com.nilesh.springCRUD.services;

import com.nilesh.springCRUD.model.UserBicycleHike;
import com.nilesh.springCRUD.model.UserWaterHike;
import com.nilesh.springCRUD.services.repository.UserBicycleHikeRepository;
import com.nilesh.springCRUD.services.repository.UserWaterHikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserBicycleHikeServices {


    @Autowired
    private UserBicycleHikeRepository repo;


    public List<UserBicycleHike> listAll(){

        return repo.findAll();
    }

    public void save(UserBicycleHike stu) {
        repo.save(stu);
    }
    public UserBicycleHike get(long id) {
         return repo.findById(id).get();
    }
    public void delete(long id) {
        repo.deleteById(id);
    }




}

package com.nilesh.springCRUD.services.repository;

import com.nilesh.springCRUD.model.BicycleHike;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface BicycleHikeRepository extends JpaRepository<BicycleHike, Long> {



}
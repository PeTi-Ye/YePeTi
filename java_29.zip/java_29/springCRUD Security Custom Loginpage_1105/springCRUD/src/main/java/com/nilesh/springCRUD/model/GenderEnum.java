package com.nilesh.springCRUD.model;

public enum GenderEnum {


    MALE,
    FEMALE
}

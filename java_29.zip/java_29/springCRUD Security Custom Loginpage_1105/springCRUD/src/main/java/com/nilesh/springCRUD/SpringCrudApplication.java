package com.nilesh.springCRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudApplication.class, args);
	}

}


/*
INSERT INTO users (username, password, enabled) VALUES ('admin', '$2a$10$bN7OWEvi6rTqJEYbZfDOg.FHmG.xPTDxJR1k9LzsR4O6Nt8zuIKwq', '1');






INSERT INTO roles (name) VALUES ('GUEST');
INSERT INTO roles (name) VALUES ('CREATOR');
INSERT INTO roles (name) VALUES ('EDITOR');
INSERT INTO roles (name) VALUES ('ADMIN');

INSERT INTO users (username,email, password, enabled,gender) VALUES ('guest','122@gmail.com',  '$2a$04$eAkqovTKYpcBL6rFrSdgweX2lH54fPhSUCHX6wLIArCeH8cLhr0tK', '1','female');
INSERT INTO users (username,email, password, enabled,gender) VALUES ('mahesh','124@gmail.com', '$2a$10$lv8PTtiNw7injglznpYeIehWW6knfFe/RnUW16TmGKtfSWRm/V2z2', '1','female');
INSERT INTO users (username,email,password, enabled,gender) VALUES ('suresh','125@gmail.com', '$2a$10$flDL1ovH.7JEy1lSpBuuHuqagrXA8K3j3ELXQFV/KXhQK.WSnP8a.', '1','female');
INSERT INTO users (username,email,password, enabled,gender) VALUES ('ramesh','123@gmail.com', '$2a$10$9k8/ODt16QFCmcmXLO2.oeVR8gHUtqpw9JeoEwEx/BKKAX9BZbbHK', '1','male');
INSERT INTO users (username,email, password, enabled,gender) VALUES ('admin','456@gmail.com', '$2a$10$bN7OWEvi6rTqJEYbZfDOg.FHmG.xPTDxJR1k9LzsR4O6Nt8zuIKwq', '1','male');
INSERT INTO users (username,email, password, enabled,gender) VALUES ('aa','789@gmail.com', '$2a$04$eAkqovTKYpcBL6rFrSdgweX2lH54fPhSUCHX6wLIArCeH8cLhr0tK', '1','female');
INSERT INTO users (username,email, password, enabled,gender) VALUES ('bb','719@gmail.com', '$2a$04$eAkqovTKYpcBL6rFrSdgweX2lH54fPhSUCHX6wLIArCeH8cLhr0tK', '1','female');



INSERT INTO users_roles (user_id, role_id) VALUES (1, 1);
INSERT INTO users_roles (user_id, role_id) VALUES (2, 2);
INSERT INTO users_roles (user_id, role_id) VALUES (3, 3);
INSERT INTO users_roles (user_id, role_id) VALUES (4, 2);
INSERT INTO users_roles (user_id, role_id) VALUES (4, 3);
INSERT INTO users_roles (user_id, role_id) VALUES (5, 4);
INSERT INTO users_roles (user_id, role_id) VALUES (6, 2);
INSERT INTO users_roles (user_id, role_id) VALUES (7, 2);




insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwalk01','30','2022-01-01','2022-02-01',20000,201,'2022-01-14','bus');
insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwalk02','40','2022-01-02','2022-02-02',20001,202,'2022-01-15','car');
insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwalk03','50','2022-01-03','2022-02-03',20002,203,'2022-01-16','train');
insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwalk04','60','2022-01-04','2022-02-04',20003,204,'2022-01-17','bus');


insert into completedwalkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,candidate_name) values('ccLondonwalk01','30','2022-01-01','2022-02-01',20001,201,'2022-01-14','bus','[CREATOR, 6]');
insert into completedwalkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,candidate_name) values('ccLondonwalk02','40','2022-01-02','2022-02-02',20002,202,'2022-01-15','car','[CREATOR, 7]');

insert into userwaterhike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,candidate_name) values('ccLondonwater01','30','2022-01-01','2022-02-01',20001,201,'2022-01-14','Yacht','[CREATOR, 6]');
insert into userwaterhike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,candidate_name) values('ccLondonwater02','40','2022-01-02','2022-02-02',20002,202,'2022-01-15','Trawler','[CREATOR, 7]');

insert into userbicyclehike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,candidate_name) values('ccLondonwater01','30','2022-01-01','2022-02-01',20001,201,'2022-01-14','Masi Giramondo','[CREATOR, 6]');
insert into userbicyclehike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,candidate_name) values('ccLondonwater02','40','2022-01-02','2022-02-02',20002,202,'2022-01-15','Kona Libre AL','[CREATOR, 7]');



insert into waterhike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwater01','30','2022-01-01','2022-02-01',20001,201,'2022-01-14','Yacht');
insert into waterhike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwater02 ','40','2022-01-02','2022-02-02',20002,202,'2022-01-15','Trawler');
insert into waterhike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwater03 ','50','2022-01-03','2022-02-03',20003,203,'2022-01-16','Boat');
insert into waterhike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonwater04','60','2022-01-04','2022-02-04',20004,204,'2022-01-17','Boat');



insert into bicyclehike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonbicycle01','30','2022-01-01','2022-02-01',20001,201,'2022-01-14','Masi Giramondo');
insert into bicyclehike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonbicycle02','40','2022-01-02','2022-02-02',20002,202,'2022-01-15','Kona Libre AL');
insert into bicyclehike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonbicycle03','50','2022-01-03','2022-02-03',20003,203,'2022-01-16','Brodie Mega Tour');
insert into bicyclehike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport) values('Londonbicycle04','60','2022-01-04','2022-02-04',20004,204,'2022-01-17','Brodie Mega Tour');



















   private Long sid;
    private String start_point;
    private int hike_period;
    private String start_date;
    private String end_date;
    private int cost;
    private int booking_amount;
    private String booking_deadline;
    private String transport;

    private String apply_or_not;





	private String email;

					private String password;

					private String birthdate;

					private String gender;

					private int phone;


login page


 */


/*

insert into student(sname,scity,hike_length,) values('Hike startpoint01','Hike endpoint01','12');
insert into student(sname,scity,hike_length) values('Hike startpoint02','Hike endpoint02','13');
insert into student(sname,scity,hike_length) values('Hike startpoint03','Hike endpoint03','14');
insert into student(sname,scity,hike_length) values('Hike startpoint04','Hike endpoint04','15');



INSERT INTO users (username, password, enabled) VALUES ('nilesh', '$2a$10$OlpVGGz1EXm.LQ/OcvmBQOFdAe3FQNYhOOXrKD6y9fhxOr2aBKwHu', '1');
INSERT INTO users (username, password, enabled) VALUES ('mahesh', '$2a$10$lv8PTtiNw7injglznpYeIehWW6knfFe/RnUW16TmGKtfSWRm/V2z2', '1');
INSERT INTO users (username, password, enabled) VALUES ('suresh', '$2a$10$flDL1ovH.7JEy1lSpBuuHuqagrXA8K3j3ELXQFV/KXhQK.WSnP8a.', '1');
INSERT INTO users (username, password, enabled) VALUES ('ramesh', '$2a$10$9k8/ODt16QFCmcmXLO2.oeVR8gHUtqpw9JeoEwEx/BKKAX9BZbbHK', '1');
INSERT INTO users (username, password, enabled) VALUES ('admin', '$2a$10$bN7OWEvi6rTqJEYbZfDOg.FHmG.xPTDxJR1k9LzsR4O6Nt8zuIKwq', '1');



INSERT INTO users (username, password, enabled) VALUES ('nileshUSER', '$2a$10$OlpVGGz1EXm.LQ/OcvmBQOFdAe3FQNYhOOXrKD6y9fhxOr2aBKwHu', '1');
INSERT INTO users (username, password, enabled) VALUES ('maheshCREATOR', '$2a$10$lv8PTtiNw7injglznpYeIehWW6knfFe/RnUW16TmGKtfSWRm/V2z2', '1');
INSERT INTO users (username, password, enabled) VALUES ('sureshEDITOR', '$2a$10$flDL1ovH.7JEy1lSpBuuHuqagrXA8K3j3ELXQFV/KXhQK.WSnP8a.', '1');
INSERT INTO users (username, password, enabled) VALUES ('rameshCREATOREDITOR', '$2a$10$9k8/ODt16QFCmcmXLO2.oeVR8gHUtqpw9JeoEwEx/BKKAX9BZbbHK', '1');
INSERT INTO users (username, password, enabled) VALUES ('adminADMIN', '$2a$10$bN7OWEvi6rTqJEYbZfDOg.FHmG.xPTDxJR1k9LzsR4O6Nt8zuIKwq', '1');









insert into userdata(sname,email,password,birthdate,gender,phone) values('Hike startpoint01','Hike endpoint01','password','birthdate','gender',2);
insert into userdata(sname,email,password,birthdate,gender,phone) values('Hike startpoint01','Hike endpoint01','password','birthdate','gender',2);
insert into userdata(sname,email,password,birthdate,gender,phone) values('Hike startpoint01','Hike endpoint01','password','birthdate','gender',2);
insert into userdata(sname,email,password,birthdate,gender,phone) values('Hike startpoint01','Hike endpoint01','password','birthdate','gender',2);




//Date
insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,completed_or_not,apply_or_not) values('walking startpoint01','30','2022-01-01','2022.02.01',20000,200,'2022.01.14.','walk','no','yes');
insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,completed_or_not,apply_or_not) values('walking startpoint02','40','2022-01-02','2022.02.02',20000,200,'2022.01.14.','walk','no','yes');
insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,completed_or_not,apply_or_not) values('walking startpoint03','50','2022-01-03','2022.02.03',20000,200,'2022.01.14.','walk','no','yes');
insert into walkinghike(start_point,hike_period,start_date,end_date,cost,booking_amount,booking_deadline,transport,completed_or_not,apply_or_not) values('walking startpoint04','60','2022-01-04','2022.02.04',20000,200,'2022.01.14.','walk','no','yes');


 */




package com.nilesh.springCRUD.services.repository;

import com.nilesh.springCRUD.model.UserCityHike;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface UserCityHikeRepository extends JpaRepository<UserCityHike, Long> {

}
package com.nilesh.springCRUD.services.repository;

import com.nilesh.springCRUD.model.UserCityHike;
import com.nilesh.springCRUD.model.UserWaterHike;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface UserWaterHikeRepository extends JpaRepository<UserWaterHike, Long> {

}
package com.nilesh.springCRUD.model;





import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "walkinghike")
public class CityHike {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sid;
    private String start_point;


    private String candidate_name;



    private int hike_period;
    private String start_date;


    private String end_date;

    private int cost;
    private int booking_amount;
    private String booking_deadline;
    private String transport;



    public String getCandidate_name() {
        return candidate_name;
    }

    public void setCandidate_name(String candidate_name) {
        this.candidate_name = candidate_name;
    }


    public Long getSid() {
        return sid;
    }

    public void setSid(Long sid) {
        this.sid = sid;
    }

    public String getStart_point() {
        return start_point;
    }

    public void setStart_point(String start_point) {
        this.start_point = start_point;
    }

    public int getHike_period() {
        return hike_period;
    }

    public void setHike_period(int hike_period) {
        this.hike_period = hike_period;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getBooking_amount() {
        return booking_amount;
    }

    public void setBooking_amount(int booking_amount) {
        this.booking_amount = booking_amount;
    }

    public String getBooking_deadline() {
        return booking_deadline;
    }

    public void setBooking_deadline(String booking_deadline) {
        this.booking_deadline = booking_deadline;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }






}

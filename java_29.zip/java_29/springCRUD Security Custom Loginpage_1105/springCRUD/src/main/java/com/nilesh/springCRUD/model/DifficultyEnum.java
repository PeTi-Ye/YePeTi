package com.nilesh.springCRUD.model;

public enum DifficultyEnum {

    EASY,
    MEDIUM,
    HARD
}

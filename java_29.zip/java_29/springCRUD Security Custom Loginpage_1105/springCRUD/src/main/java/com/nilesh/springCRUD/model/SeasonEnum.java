package com.nilesh.springCRUD.model;

public enum SeasonEnum {


    SPRING,
    SUMMER,
    AUTUMN,
    WINTER

}

package com.nilesh.springCRUD.controller;

import java.util.List;

import com.nilesh.springCRUD.model.*;
import com.nilesh.springCRUD.services.*;
import org.springframework.security.core.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nilesh.springCRUD.model.CityHike;
//import com.nilesh.springCRUD.services.WalkingHikeServicesServices;


@Controller
public class AppController {



	@Autowired
	private UserServices service00;




	@Autowired
	private UsersRolesServices service000;
	
	@Autowired
	private StudentServices service;

	@Autowired
	private CityHikeServices service2;

	@Autowired
	private UserCityHikeServices service22;


	@Autowired
	private WaterHikeServices service3;


	@Autowired
	private UserWaterHikeServices service33;


	@Autowired
	private BicycleHikeServices service4;


	@Autowired
	private UserBicycleHikeServices service44;



	@RequestMapping("/test")
	public String newStudentPage_search2(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		return "test";
	}


	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx search kezd xxxxxxxxxxxxxxxxxx





	@RequestMapping("/search")
	public String newStudentPage_search(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		return "search";
	}


	@RequestMapping("/search_water")
	public String newStudentPage_search_water(Model model) {
		List<WaterHike> listStu = service3.listAll();
		model.addAttribute("listStudent",listStu);
		return "search_water";
	}


	@RequestMapping("/search_bicycle")
	public String newStudentPage_search_bicycle(Model model) {
		List<BicycleHike> listStu = service4.listAll();
		model.addAttribute("listStudent",listStu);
		return "search_bicycle";
	}


	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx search vege xxxxxxxxxxxxxxxxxx


	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx index kezd xxxxxxxxxxxxxxxxxx


	@RequestMapping("/index")
	public String viewHomePage(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "index";
	}


	@RequestMapping("/AboutUs")
	public String viewHomePage_AboutUs(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "AboutUs";
	}



	@RequestMapping("/ContactUs")
	public String viewHomePage_ContactUs(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "ContactUs";
	}


	@RequestMapping("/ToursPage")
	public String view_ToursPage(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "ToursPage";
	}


	@RequestMapping("/UsersToursPage")
	public String view_UsersToursPage(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "UsersToursPage";
	}


	@RequestMapping("/SearchPage")
	public String view_SearchPage(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "SearchPage";
	}

	@RequestMapping("/UsersSearchPage")
	public String view_UsersSearchPage(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "UsersSearchPage";
	}

	@RequestMapping("/FilterPage")
	public String view_FilterPage(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "FilterPage";
	}

	@RequestMapping("/UsersFilterPage")
	public String view_UsersFilterPage(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);
		return "UsersFilterPage";
	}




	@RequestMapping("/index2")
	public String viewHomePage2(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);


		List<UserCityHike> listStu22= service22.listAll();
		model.addAttribute("listStudent22",listStu22);



		return "index2";
	}



	@RequestMapping("/bicycle_index")
	public String newStudentPage5(Model model) {
		List<BicycleHike> listStu = service4.listAll();
		List<UserBicycleHike> listStu44 = service44.listAll();


		model.addAttribute("listStudent",listStu);
		model.addAttribute("listStudent44",listStu44);
		return "bicycle_index";
	}



	@RequestMapping("/water_index")
	public String newStudentPage4(Model model) {
		List<WaterHike> listStu = service3.listAll();
		List<UserWaterHike> listStu33 = service33.listAll();

		model.addAttribute("listStudent",listStu);
		model.addAttribute("listStudent33",listStu33);
		return "water_index";
	}


	@RequestMapping("/userdata_index")
	public String newStudentPage6(Model model) {
		List<Student> listStu = service.listAll();
		List<User> listStu00 = service00.listAll();
		List<UsersRoles> listStu000 = service000.listAll();


		model.addAttribute("listStudent",listStu);
		model.addAttribute("listStudent00",listStu00);
		model.addAttribute("listStudent000",listStu000);

		return "userdata_index";
	}

	@RequestMapping("/creatorpanel_index")
	public String newStudentPage_creatorpanel(Model model) {
		List<UserCityHike> listStu= service22.listAll();
		model.addAttribute("listStudent",listStu);

		return "creatorpanel_index";
	}

	@RequestMapping("/usercity_search")
	public String newStudentPage_usercity_search(Model model) {
		List<UserCityHike> listStu= service22.listAll();
		model.addAttribute("listStudent",listStu);

		return "usercity_search";
	}

	@RequestMapping("/usercity_filter")
	public String newStudentPage_usercity_filter(Model model) {
		List<UserCityHike> listStu= service22.listAll();
		model.addAttribute("listStudent",listStu);

		return "usercity_filter";
	}

	@RequestMapping("/userwater_search")
	public String newStudentPage_usercity_search33(Model model) {
		List<UserWaterHike> listStu= service33.listAll();
		model.addAttribute("listStudent",listStu);

		return "userwater_search";
	}

	@RequestMapping("/userwater_filter")
	public String newStudentPage_userwater_filter33(Model model) {
		List<UserWaterHike> listStu= service33.listAll();
		model.addAttribute("listStudent",listStu);

		return "userwater_filter";
	}


	@RequestMapping("/userbicycle_search")
	public String newStudentPage_usercity_search44(Model model) {
		List<UserBicycleHike> listStu= service44.listAll();
		model.addAttribute("listStudent",listStu);

		return "userbicycle_search";
	}

	@RequestMapping("/userbicycle_filter")
	public String newStudentPage_userbicycle_filter44(Model model) {
		List<UserBicycleHike> listStu= service44.listAll();
		model.addAttribute("listStudent",listStu);

		return "userbicycle_filter";
	}





	@GetMapping("/login")
	public String showLoginPage() {
		Authentication authentication=SecurityContextHolder.getContext().getAuthentication();
		if(authentication==null || authentication instanceof AnonymousAuthenticationToken) {
			return "/login";
		}
		return "redirect:/";
	}



	@RequestMapping("/completedwalk_index")
	public String viewHomePage22(Model model) {
		List<UserCityHike> listStu= service22.listAll();
		model.addAttribute("listStudent",listStu);
		return "completedwalk_index";
	}

	@RequestMapping("/user_water_index")
	public String viewHomePage_user_water_index(Model model) {
		List<UserWaterHike> listStu= service33.listAll();
		model.addAttribute("listStudent",listStu);
		return "user_water_index";
	}

	@RequestMapping("/user_bicycle_index")
	public String viewHomePage_user_bicycle_index(Model model) {
		List<UserBicycleHike> listStu= service44.listAll();
		model.addAttribute("listStudent",listStu);
		return "user_bicycle_index";
	}



//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx index vege xxxxxxxxxxxxxxxxxx








//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx add,kezd xxxxxxxxxxxxxxxxx
//
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx add, kezd xxxxxxxxxxxxxxxxx


	@RequestMapping("/new")
	public String newStudentPage(Model model) {
		CityHike stu = new CityHike();
		model.addAttribute("student",stu);
		return "new_student";
	}





	@RequestMapping("new_water")
	public String newStudentPage02_Water(Model model) {
		WaterHike stu = new WaterHike();
		model.addAttribute("student",stu);
		return "new_water";
	}



	@RequestMapping("/new_bicycle")
	public String newStudentPage03(Model model) {
		BicycleHike stu = new BicycleHike();
		model.addAttribute("student",stu);
		return "new_bicycle";
	}


	@RequestMapping("/new_userdata")
	public String newStudentPage04(Model model) {
		Student stu = new Student();
		model.addAttribute("student",stu);
		return "new_userdata";
	}

	@RequestMapping("/new_userdata2")
	public String new_userdata2_page(Model model) {
		User stu = new User();
		UsersRoles stu2 = new UsersRoles();

		model.addAttribute("student",stu);
		model.addAttribute("student2",stu2);
		return "new_userdata2";
	}

	@RequestMapping("/new_role")
	public String new_userdata3_page(Model model) {
		UsersRoles stu = new UsersRoles();
		model.addAttribute("student",stu);
		return "new_role";
	}


	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	// new user kezd
	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	@RequestMapping("/new_completedwalk")
	public String new_completedwalk(Model model) {
		UserCityHike stu = new UserCityHike();
		model.addAttribute("student",stu);
		return "new_completedwalk";
	}

	@RequestMapping("/new_userwater")
	public String new_userwater(Model model) {
		UserWaterHike stu = new UserWaterHike();
		model.addAttribute("student",stu);
		return "new_userwater";
	}


	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	// new user vege
	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx



	@RequestMapping(value="/save", method = RequestMethod.POST )

	public String saveStudent(@ModelAttribute("student") CityHike stu) {
		service2.save(stu);
		return "redirect:/index2";
	}

	@RequestMapping(value="/save2", method = RequestMethod.POST )

	public String saveStudent_Water(@ModelAttribute("student") WaterHike stu) {
		service3.save(stu);
		return "redirect:/water_index";
	}



	@RequestMapping(value="/save3", method = RequestMethod.POST )

	public String saveStudent_Bicycle(@ModelAttribute("student") BicycleHike stu) {
		service4.save(stu);
		return "redirect:/bicycle_index";
	}

	@RequestMapping(value="/save4", method = RequestMethod.POST )

	public String saveStudent_save(@ModelAttribute("student") Student stu) {
		service.save(stu);
		return "redirect:/userdata_index";
	}




	@RequestMapping(value="/save00", method = RequestMethod.POST )
	public String saveStudent_save00(@ModelAttribute("student") User stu) {
		service00.save(stu);
		return "redirect:/new_userdata2";
	}

	@RequestMapping(value="/edit_save00", method = RequestMethod.POST )
	public String saveStudent_edit_save00(@ModelAttribute("student") User stu) {
		service00.save(stu);
		return "redirect:/edit_userdata";
	}


	@RequestMapping(value="/register_save00", method = RequestMethod.POST )

	public String saveStudent_register_save00(@ModelAttribute("student") User stu) {
		service00.save(stu);


		return "redirect:/register";
	}

	@RequestMapping(value="/save000", method = RequestMethod.POST )
	public String saveStudent_save000(@ModelAttribute("student") UsersRoles stu) {
		service000.save(stu);
		return "redirect:/userdata_index";


	}

	@RequestMapping(value="/register_save000", method = RequestMethod.POST )
	public String saveStudent_register_save000(@ModelAttribute("student") UsersRoles stu) {
		service000.save(stu);
		return "redirect:/login";
	}

	@RequestMapping(value="/edit_save000", method = RequestMethod.POST )
	public String saveStudent_edit_save000(@ModelAttribute("student") UsersRoles stu) {
		service000.save(stu);
		return "redirect:/userdata_index";


	}



	@RequestMapping(value="/save11", method = RequestMethod.POST )

	public String saveCompleted_Walk(@ModelAttribute("student") UserCityHike stu) {
		service22.save(stu);
		return "redirect:/completedwalk_index";

	}

	@RequestMapping(value="/save111", method = RequestMethod.POST )

	public String saveCompleted_Walk111(@ModelAttribute("student") UserCityHike stu) {
		service22.save(stu);
		return "redirect:/index2";

	}

	@RequestMapping(value="/save33", method = RequestMethod.POST )

	public String saveStudent_Water33(@ModelAttribute("student") UserWaterHike stu) {
		service33.save(stu);
		return "redirect:/user_water_index";
	}

	@RequestMapping(value="/save333", method = RequestMethod.POST )

	public String saveStudent_Water333(@ModelAttribute("student") UserWaterHike stu) {
		service33.save(stu);
		return "redirect:/water_index";
	}

	@RequestMapping(value="/save444", method = RequestMethod.POST )
	public String saveStudent_Bicycle444(@ModelAttribute("student") UserBicycleHike stu) {
		service44.save(stu);
		return "redirect:/bicycle_index";
	}





//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx add,kezd xxxxxxxxxxxxxxxxx
//
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx add, kezd xxxxxxxxxxxxxxxxx



	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// , delete  kezd
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx



	@RequestMapping("/delete/{sid}")
	public String deleteStudentpage_walking(@PathVariable (name="sid") int id) {
		service2.delete(id);
		return "redirect:/index2";
	}

	@RequestMapping("/delete2/{sid}")
	public String deleteStudentpage_water(@PathVariable (name="sid") int id) {
		service3.delete(id);
		return "redirect:/water_index";
	}



	@RequestMapping("/delete3/{sid}")
	public String deleteStudentpage_bicycle(@PathVariable (name="sid") int id) {
		service4.delete(id);
		return "redirect:/bicycle_index";
	}



	@RequestMapping("/delete4/{sid}")
	public String deleteStudentpage_delete(@PathVariable (name="sid") int id) {
		service.delete(id);
		return "redirect:/userdata_index";
	}



	@RequestMapping("/delete11/{sid}")
	public String deleteCompleted_walk(@PathVariable (name="sid") int id) {
		service22.delete(id);
		return "redirect:/";

	}

	@RequestMapping("/delete33/{sid}")
	public String delete_User_water(@PathVariable (name="sid") int id) {
		service33.delete(id);
		return "redirect:/user_water_index";

	}


	@RequestMapping("/delete44/{sid}")
	public String delete_User_bicycle(@PathVariable (name="sid") int id) {
		service44.delete(id);
		return "redirect:/user_bicycle_index";

	}

	@RequestMapping("/delete0000/{sid}")
	public String delete_User_delete0000(@PathVariable (name="sid") int id) {
		service00.delete(id);
		service000.delete(id);


		return "redirect:/userdata_index";

	}

	@RequestMapping("/delete00/{sid}")
	public String delete_User_delete00(@PathVariable (name="sid") int id) {
		service00.delete(id);

		return "redirect:/userdata_index";

	}

	@RequestMapping("/delete000/{sid}")
	public String delete_User_delete000(@PathVariable (name="sid") int id) {
		service000.delete(id);
		return "redirect:/userdata_index";

	}

	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// , delete  vege
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx





	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// , edit  kezd
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx





	@RequestMapping("/edit/{sid}")
	public ModelAndView showEditStudentpage(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_student");

		CityHike stu=service2.get(id);

		mav.addObject("student",stu);
		return mav;
	}


	@RequestMapping("/edit_water/{sid}")
	public ModelAndView showEditStudentpage2(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_water");
		WaterHike stu=service3.get(id);
		mav.addObject("student",stu);
		return mav;
	}


	@RequestMapping("/edit_bicycle/{sid}")
	public ModelAndView showEditStudentpage3(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_bicycle");

		BicycleHike stu=service4.get(id);

		mav.addObject("student",stu);

		return mav;
	}


	@RequestMapping("/edit_userdata/{sid}")
	public ModelAndView showEditStudentpage_edit(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_userdata");
		User stu=service00.get(id);
		UsersRoles stu2=service000.get(id);
		mav.addObject("student",stu);
		mav.addObject("student2",stu2);
		return mav;
	}
/*
	@RequestMapping("/new_userdata2")
	public String new_userdata2_page(Model model) {
		User stu = new User();
		UsersRoles stu2 = new UsersRoles();

		model.addAttribute("student",stu);
		model.addAttribute("student2",stu2);
		return "new_userdata2";
	}
*/

	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	// completed kezd
	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	@RequestMapping("/edit_completedwalk/{sid}")
	public ModelAndView showEditCompletedWalk(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_completedwalk");

		UserCityHike stu=service22.get(id);

		mav.addObject("student",stu);

		return mav;
	}

	@RequestMapping("/edit_userwater/{sid}")
	public ModelAndView show_edit_userwater(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_userwater");

		UserWaterHike stu=service33.get(id);

		mav.addObject("student",stu);

		return mav;
	}




	@RequestMapping("/edit_completedwalk2/{sid}")
	public ModelAndView showEditCompletedWalk2(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_completedwalk2");

		CityHike stu=service2.get(id);

		mav.addObject("student",stu);

		return mav;
	}



	@RequestMapping("/edit_userwater2/{sid}")
	public ModelAndView showEdit_userwater(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_userwater2");
		WaterHike stu=service3.get(id);
		mav.addObject("student",stu);
		return mav;
	}


	@RequestMapping("/edit_userbicycle2/{sid}")
	public ModelAndView showEdit_userbicycle(@PathVariable (name="sid") int id) {
		ModelAndView mav=new ModelAndView("edit_userbicycle2");
		BicycleHike stu=service4.get(id);
		mav.addObject("student",stu);
		return mav;
	}


	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// , edit  vege
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// add, delete edit vege
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx



	@RequestMapping("/register")
	public String newStudentPage3(Model model) {


		User stu = new User();
		UsersRoles stu2 = new UsersRoles();

		model.addAttribute("student",stu);
		model.addAttribute("student2",stu2);


		return "register";
	}




	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// walk filter kezd
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	@RequestMapping("/walk_filter_id")
	public String walk_filter_id_page(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);
		return "walk_filter_id";
	}


	@RequestMapping("/water_filter_id")
	public String water_filter_id_page(Model model) {
		List<WaterHike> listStu = service3.listAll();
		model.addAttribute("listStudent",listStu);
		return "water_filter_id";
	}

	@RequestMapping("/bicycle_filter_id")
	public String bicycle_filter_id_page(Model model) {
		List<BicycleHike> listStu = service4.listAll();
		model.addAttribute("listStudent",listStu);
		return "bicycle_filter_id";
	}




	//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// walk filter vege
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

	@RequestMapping("/kordiagram")
	public String kordiagram_page(Model model) {

		List<CityHike> listStu = service2.listAll();


		model.addAttribute("listStudent",listStu);

		return "kordiagram";
	}

	@RequestMapping("/vonaldiagram")
	public String vonaldiagram_page(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);

		return "vonaldiagram";
	}

	@RequestMapping("/histogram")
	public String histogram_page(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);

		return "histogram";
	}


	@RequestMapping("/oszlopdiagram")
	public String oszlopdiagram_page(Model model) {
		List<CityHike> listStu = service2.listAll();
		model.addAttribute("listStudent",listStu);

		return "oszlopdiagram";
	}
















}
